# No.69 v1.0 reproducibility kit

Author: Ryutaro Yonezu. Research preprint, 14 November 2026.

Target: permutations avoiding **consecutive** patterns `{123,132,312}`. Main asymptotic popularities: `213 -> 1/2`, `231 -> 1/2`, `321 -> 0`. The separate manuscript contains the all-n proof; code checks only finite instances.

## Python 3.10+ / Windows PowerShell 5.1

Unzip and run in this directory:

```powershell
python -B -I .\verify_v02.py
python -B -I .\verify_class10.py
```

`verify_v02.py` should end in `ALL FINITE CHECKS PASS; INFINITE PROOF AND NOVELTY NEED INDEPENDENT AUDIT`.

## C++17 (optional, if g++ is installed)

```powershell
g++ -O2 -std=c++17 -o independent_bruteforce.exe .\independent_bruteforce.cpp
.\independent_bruteforce.exe
g++ -O2 -std=c++17 -o independent_all_patterns.exe .\independent_all_patterns.cpp
.\independent_all_patterns.exe
```

The `EXACT_TABLE.csv` was produced from finite recurrence calculations. It is NOT a certified infinite limit proof.

The code and data are unchanged byte-for-byte from the independently audited v0.1 or v0.3 source packages. The package omits all Windows raw transcripts, user machine paths, credentials, and unpublished private audit attachments.

Human peer review: none. Independent AI reading: within reported scope. Historical novelty: inconclusive. Copyright (c) 2026 Ryutaro Yonezu. All rights reserved.
